package com.example.adhkar

import android.content.Context

/** إعدادات الفقاعة العائمة: اللون والحجم والموضع. */
object BubbleSettings {
    const val KEY_COLOR = "bubble_color"
    const val KEY_SIZE = "bubble_size_dp"
    const val KEY_X = "bubble_x"
    const val KEY_Y = "bubble_y"

    const val DEFAULT_SIZE = 64
    const val MIN_SIZE = 40
    const val MAX_SIZE = 120

    val DEFAULT_COLOR: Int = 0xFF1B6B4F.toInt()

    val COLORS: List<Int> = listOf(
        0xFF1B6B4F.toInt(), // أخضر
        0xFF1565C0.toInt(), // أزرق
        0xFF6A1B9A.toInt(), // بنفسجي
        0xFFE65100.toInt(), // برتقالي
        0xFF37474F.toInt()  // رمادي داكن
    )

    fun color(context: Context): Int =
        CounterStore.prefs(context).getInt(KEY_COLOR, DEFAULT_COLOR)

    fun setColor(context: Context, value: Int) {
        CounterStore.prefs(context).edit().putInt(KEY_COLOR, value).apply()
    }

    fun sizeDp(context: Context): Int =
        CounterStore.prefs(context).getInt(KEY_SIZE, DEFAULT_SIZE)

    fun setSizeDp(context: Context, value: Int) {
        CounterStore.prefs(context).edit().putInt(KEY_SIZE, value).apply()
    }

    /** آخر موضع محفوظ للفقاعة (بالبكسل)، أو null إن لم يُحفظ شيء بعد. */
    fun position(context: Context): Pair<Int, Int>? {
        val p = CounterStore.prefs(context)
        return if (p.contains(KEY_X) && p.contains(KEY_Y)) {
            p.getInt(KEY_X, 0) to p.getInt(KEY_Y, 0)
        } else null
    }

    fun savePosition(context: Context, x: Int, y: Int) {
        CounterStore.prefs(context).edit().putInt(KEY_X, x).putInt(KEY_Y, y).apply()
    }
}

/** تقدّم كل ذكر (عدد المرات التي قيلت). */
object DhikrProgress {
    private fun key(id: String) = "p_$id"

    fun get(context: Context, id: String): Int =
        CounterStore.prefs(context).getInt(key(id), 0)

    fun increment(context: Context, id: String, target: Int): Int {
        val current = get(context, id)
        if (current >= target) return current
        val value = current + 1
        CounterStore.prefs(context).edit().putInt(key(id), value).apply()
        return value
    }

    fun reset(context: Context, ids: List<String>) {
        val editor = CounterStore.prefs(context).edit()
        ids.forEach { editor.remove(key(it)) }
        editor.apply()
    }
}
