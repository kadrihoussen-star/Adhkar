package com.example.adhkar

data class Dhikr(val id: String, val text: String, val target: Int)

data class Category(val id: String, val title: String, val items: List<Dhikr>)

/**
 * نصوص الأذكار (مأخوذة من حصن المسلم وما صحّ في السنّة).
 * يُنصح بمراجعتها على مصدر موثوق قبل نشر التطبيق.
 */
object AdhkarData {

    private const val KURSI =
        "اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ"

    private const val IKHLAS =
        "قُلْ هُوَ اللَّهُ أَحَدٌ\nاللَّهُ الصَّمَدُ\nلَمْ يَلِدْ وَلَمْ يُولَدْ\nوَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ"

    private const val FALAQ =
        "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ\nمِنْ شَرِّ مَا خَلَقَ\nوَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ\nوَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ\nوَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ"

    private const val NAS =
        "قُلْ أَعُوذُ بِرَبِّ النَّاسِ\nمَلِكِ النَّاسِ\nإِلَهِ النَّاسِ\nمِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ\nالَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ\nمِنَ الْجِنَّةِ وَالنَّاسِ"

    private const val MORNING_GREETING =
        "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ"

    private const val EVENING_GREETING =
        "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ"

    private const val SAYYID =
        "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ"

    private const val BISMILLAH =
        "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ"

    private const val RADEETU =
        "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صلى الله عليه وسلم نَبِيًّا"

    private const val AFINI =
        "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَهَ إِلَّا أَنْتَ"

    private const val HASBI =
        "حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ"

    private const val TAHLIL =
        "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ"

    private const val SUBHAN_BIHAMDIH = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ"

    private const val SALAT = "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ"

    private const val TAMMAT = "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ"

    private const val ISTIGHFAR = "أَسْتَغْفِرُ اللَّهَ"

    private const val SALAM =
        "اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ"

    private const val AFTER_TAHLIL =
        "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، اللَّهُمَّ لَا مَانِعَ لِمَا أَعْطَيْتَ، وَلَا مُعْطِيَ لِمَا مَنَعْتَ، وَلَا يَنْفَعُ ذَا الْجَدِّ مِنْكَ الْجَدُّ"

    private const val SUBHANALLAH = "سُبْحَانَ اللَّهِ"
    private const val ALHAMDULILLAH = "الْحَمْدُ لِلَّهِ"
    private const val ALLAHU_AKBAR = "اللَّهُ أَكْبَرُ"

    private fun daily(prefix: String, greeting: String): List<Dhikr> = listOf(
        Dhikr("${prefix}_kursi", KURSI, 1),
        Dhikr("${prefix}_ikhlas", IKHLAS, 3),
        Dhikr("${prefix}_falaq", FALAQ, 3),
        Dhikr("${prefix}_nas", NAS, 3),
        Dhikr("${prefix}_greet", greeting, 1),
        Dhikr("${prefix}_sayyid", SAYYID, 1),
        Dhikr("${prefix}_bism", BISMILLAH, 3),
        Dhikr("${prefix}_radeetu", RADEETU, 3),
        Dhikr("${prefix}_afini", AFINI, 3),
        Dhikr("${prefix}_hasbi", HASBI, 7),
        Dhikr("${prefix}_tahlil", TAHLIL, 10),
        Dhikr("${prefix}_tasbih", SUBHAN_BIHAMDIH, 100),
        Dhikr("${prefix}_salat", SALAT, 10)
    )

    val morning: List<Dhikr> = daily("m", MORNING_GREETING)

    val evening: List<Dhikr> =
        daily("e", EVENING_GREETING) + Dhikr("e_tammat", TAMMAT, 3)

    val afterPrayer: List<Dhikr> = listOf(
        Dhikr("a_istighfar", ISTIGHFAR, 3),
        Dhikr("a_salam", SALAM, 1),
        Dhikr("a_tahlil1", AFTER_TAHLIL, 1),
        Dhikr("a_subhan", SUBHANALLAH, 33),
        Dhikr("a_hamd", ALHAMDULILLAH, 33),
        Dhikr("a_akbar", ALLAHU_AKBAR, 33),
        Dhikr("a_tahlil2", TAHLIL, 1),
        Dhikr("a_kursi", KURSI, 1),
        Dhikr("a_ikhlas", IKHLAS, 1),
        Dhikr("a_falaq", FALAQ, 1),
        Dhikr("a_nas", NAS, 1)
    )

    val categories: List<Category> = listOf(
        Category("morning", "أذكار الصباح", morning),
        Category("evening", "أذكار المساء", evening),
        Category("afterPrayer", "أذكار بعد الصلاة", afterPrayer)
    )
}
