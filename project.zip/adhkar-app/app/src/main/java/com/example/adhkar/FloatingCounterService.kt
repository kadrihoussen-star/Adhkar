package com.example.adhkar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs

/** خدمة تعرض فقاعة عدّاد صغيرة فوق التطبيقات الأخرى. */
class FloatingCounterService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private lateinit var params: WindowManager.LayoutParams

    // يحدّث الفقاعة عندما يتغيّر العدّاد أو اللون أو الحجم من التطبيق
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        val view = bubble
        if (view != null) {
            if (key == CounterStore.KEY_COUNT) {
                view.text = CounterStore.get(this).toString()
            } else if (key == BubbleSettings.KEY_COLOR || key == BubbleSettings.KEY_SIZE) {
                applyStyle(view, true)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        CounterStore.prefs(this).registerOnSharedPreferenceChangeListener(prefsListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )

        if (bubble == null) showBubble()
        return START_STICKY
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
        ).toInt()

    /** يطبّق اللون والحجم المحفوظين على الفقاعة. */
    private fun applyStyle(view: TextView, relayout: Boolean) {
        val base = BubbleSettings.color(this)
        val sizeDp = BubbleSettings.sizeDp(this)

        view.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(230, Color.red(base), Color.green(base), Color.blue(base)))
            setStroke(dp(2), Color.WHITE)
        }
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeDp / 64f * 20f)

        if (relayout) {
            params.width = dp(sizeDp)
            params.height = dp(sizeDp)
            windowManager.updateViewLayout(view, params)
        }
    }

    private fun showBubble() {
        val size = dp(BubbleSettings.sizeDp(this))

        val view = TextView(this).apply {
            text = CounterStore.get(this@FloatingCounterService).toString()
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            elevation = dp(6).toFloat()
        }

        // آخر موضع محفوظ، مع التأكد من بقاء الفقاعة داخل الشاشة
        val dm = resources.displayMetrics
        val saved = BubbleSettings.position(this)

        params = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (saved?.first ?: dp(16)).coerceIn(0, maxOf(0, dm.widthPixels - size))
            y = (saved?.second ?: dp(200)).coerceIn(0, maxOf(0, dm.heightPixels - size))
        }

        applyStyle(view, false)
        view.setOnTouchListener(DragOrTapListener())
        windowManager.addView(view, params)
        bubble = view
    }

    /** سحب الفقاعة لتحريكها، والضغطة السريعة للعدّ. */
    private inner class DragOrTapListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false
        private val slop = dp(8)

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        windowManager.updateViewLayout(v, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        BubbleSettings.savePosition(
                            this@FloatingCounterService, params.x, params.y
                        )
                    } else {
                        val value = CounterStore.increment(this@FloatingCounterService)
                        (v as TextView).text = value.toString()
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    }
                }
            }
            return true
        }
    }

    private fun buildNotification(): Notification {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.channel_name),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingCounterService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_add)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(openApp)
            .addAction(0, getString(R.string.stop_bubble), stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        CounterStore.prefs(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
        bubble?.let { windowManager.removeView(it) }
        bubble = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.example.adhkar.STOP"
        private const val CHANNEL_ID = "floating_counter"
        private const val NOTIFICATION_ID = 1
    }
}
