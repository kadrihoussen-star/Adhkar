package com.example.adhkar

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // إذن الإشعارات (أندرويد 13 فما فوق) لإظهار إشعار الخدمة
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        setContent {
            // واجهة من اليمين إلى اليسار
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        CounterScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun CounterScreen() {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var count by remember { mutableIntStateOf(CounterStore.get(context)) }

    // مزامنة العدد مع الفقاعة العائمة
    DisposableEffect(Unit) {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == CounterStore.KEY_COUNT) count = CounterStore.get(context)
        }
        CounterStore.prefs(context).registerOnSharedPreferenceChangeListener(listener)
        onDispose {
            CounterStore.prefs(context).unregisterOnSharedPreferenceChangeListener(listener)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "عدّاد التسبيح",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(32.dp))

        // الدائرة الكبيرة: اضغط عليها للعدّ
        Box(
            modifier = Modifier
                .size(220.dp)
                .background(Color(0xFF1B6B4F), CircleShape)
                .clickable {
                    count = CounterStore.increment(context)
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = count.toString(),
                color = Color.White,
                fontSize = 64.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(32.dp))

        OutlinedButton(
            onClick = { CounterStore.reset(context); count = 0 },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تصفير العدّاد") }

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = { startBubble(context) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تشغيل الفقاعة العائمة") }

        Spacer(Modifier.height(8.dp))

        OutlinedButton(
            onClick = { context.stopService(Intent(context, FloatingCounterService::class.java)) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("إيقاف الفقاعة") }
    }
}

private fun startBubble(context: Context) {
    if (!Settings.canDrawOverlays(context)) {
        Toast.makeText(
            context,
            "فعّل خيار «العرض فوق التطبيقات الأخرى» ثم ارجع واضغط تشغيل",
            Toast.LENGTH_LONG
        ).show()
        context.startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
        )
        return
    }
    ContextCompat.startForegroundService(
        context, Intent(context, FloatingCounterService::class.java)
    )
}
