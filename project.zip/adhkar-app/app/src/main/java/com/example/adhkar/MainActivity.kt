package com.example.adhkar

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // إذن الإشعارات (أندرويد 13 فما فوق) لإظهار إشعار الخدمة
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        setContent {
            // واجهة من اليمين إلى اليسار
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        AppRoot()
                    }
                }
            }
        }
    }
}

/** التنقل بين الشاشات: home / free / settings / cat:<id> */
@Composable
fun AppRoot() {
    var screen by rememberSaveable { mutableStateOf("home") }
    val goHome = { screen = "home" }

    BackHandler(enabled = screen != "home") { goHome() }

    when {
        screen == "home" -> HomeScreen(onOpen = { screen = it })
        screen == "free" -> FreeCounterScreen(onBack = goHome)
        screen == "settings" -> BubbleSettingsScreen(onBack = goHome)
        screen.startsWith("cat:") -> {
            val id = screen.removePrefix("cat:")
            val category = AdhkarData.categories.firstOrNull { it.id == id }
            if (category != null) CategoryScreen(category, onBack = goHome) else goHome()
        }
        else -> goHome()
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val entries = listOf(
        "cat:morning" to "أذكار الصباح",
        "cat:evening" to "أذكار المساء",
        "cat:afterPrayer" to "أذكار بعد الصلاة",
        "free" to "العدّاد الحر والفقاعة",
        "settings" to "إعدادات الفقاعة"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("أذكار", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        entries.forEach { (key, title) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(key) }
            ) {
                Text(
                    text = title,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(20.dp)
                )
            }
        }
    }
}

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = onBack) { Text("رجوع") }
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.size(64.dp))
    }
}

/** العدّاد الحر مع تشغيل الفقاعة العائمة وإيقافها. */
@Composable
fun FreeCounterScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var count by remember { mutableIntStateOf(CounterStore.get(context)) }

    // مزامنة العدد مع الفقاعة العائمة
    DisposableEffect(Unit) {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == CounterStore.KEY_COUNT) count = CounterStore.get(context)
        }
        CounterStore.prefs(context).registerOnSharedPreferenceChangeListener(listener)
        onDispose {
            CounterStore.prefs(context).unregisterOnSharedPreferenceChangeListener(listener)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenHeader("العدّاد الحر", onBack)
        Spacer(Modifier.height(24.dp))

        // الدائرة الكبيرة: اضغط عليها للعدّ
        Box(
            modifier = Modifier
                .size(220.dp)
                .background(Color(0xFF1B6B4F), CircleShape)
                .clickable {
                    count = CounterStore.increment(context)
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = count.toString(),
                color = Color.White,
                fontSize = 64.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(32.dp))

        OutlinedButton(
            onClick = { CounterStore.reset(context); count = 0 },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تصفير العدّاد") }

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = { startBubble(context) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تشغيل الفقاعة العائمة") }

        Spacer(Modifier.height(8.dp))

        OutlinedButton(
            onClick = { context.stopService(Intent(context, FloatingCounterService::class.java)) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("إيقاف الفقاعة") }
    }
}

/** اختيار لون الفقاعة وحجمها، وتُطبَّق التغييرات فوراً. */
@Composable
fun BubbleSettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var color by remember { mutableIntStateOf(BubbleSettings.color(context)) }
    var size by remember { mutableFloatStateOf(BubbleSettings.sizeDp(context).toFloat()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        ScreenHeader("إعدادات الفقاعة", onBack)
        Spacer(Modifier.height(24.dp))

        Text("اللون", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BubbleSettings.COLORS.forEach { c ->
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(c), CircleShape)
                        .then(
                            if (c == color) Modifier.border(3.dp, Color.Black, CircleShape)
                            else Modifier
                        )
                        .clickable {
                            color = c
                            BubbleSettings.setColor(context, c)
                        }
                )
            }
        }

        Spacer(Modifier.height(28.dp))

        Text("الحجم: ${size.roundToInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Slider(
            value = size,
            onValueChange = { size = it },
            onValueChangeFinished = { BubbleSettings.setSizeDp(context, size.roundToInt()) },
            valueRange = BubbleSettings.MIN_SIZE.toFloat()..BubbleSettings.MAX_SIZE.toFloat()
        )

        Spacer(Modifier.height(16.dp))
        Text("معاينة", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .size(size.dp)
                .background(Color(color), CircleShape)
                .border(2.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("0", color = Color.White, fontSize = (size / 64f * 20f).sp)
        }

        Spacer(Modifier.height(24.dp))
        Text(
            "تُطبَّق التغييرات فوراً على الفقاعة إن كانت تعمل. " +
                "ويُحفظ مكانها تلقائياً عند سحبها.",
            fontSize = 14.sp
        )
    }
}

private fun startBubble(context: Context) {
    if (!Settings.canDrawOverlays(context)) {
        Toast.makeText(
            context,
            "فعّل خيار «العرض فوق التطبيقات الأخرى» ثم ارجع واضغط تشغيل",
            Toast.LENGTH_LONG
        ).show()
        context.startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
        )
        return
    }
    ContextCompat.startForegroundService(
        context, Intent(context, FloatingCounterService::class.java)
    )
}
