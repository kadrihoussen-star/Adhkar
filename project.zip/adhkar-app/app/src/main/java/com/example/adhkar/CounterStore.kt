package com.example.adhkar

import android.content.Context
import android.content.SharedPreferences

/** تخزين قيمة العدّاد بحيث يشترك فيها التطبيق والفقاعة العائمة. */
object CounterStore {
    private const val PREFS = "adhkar_prefs"
    const val KEY_COUNT = "count"

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun get(context: Context): Int = prefs(context).getInt(KEY_COUNT, 0)

    fun increment(context: Context): Int {
        val value = get(context) + 1
        prefs(context).edit().putInt(KEY_COUNT, value).apply()
        return value
    }

    fun reset(context: Context) {
        prefs(context).edit().putInt(KEY_COUNT, 0).apply()
    }
}
