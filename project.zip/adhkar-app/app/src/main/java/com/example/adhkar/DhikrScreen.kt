package com.example.adhkar

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** شاشة قسم من الأذكار: اضغط على الذكر لتزيد العدّاد حتى يكتمل. */
@Composable
fun CategoryScreen(category: Category, onBack: () -> Unit) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current

    val counts = remember {
        mutableStateMapOf<String, Int>().apply {
            category.items.forEach { put(it.id, DhikrProgress.get(context, it.id)) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("رجوع") }
            Text(category.title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = {
                DhikrProgress.reset(context, category.items.map { it.id })
                category.items.forEach { counts[it.id] = 0 }
            }) { Text("إعادة") }
        }

        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(category.items, key = { it.id }) { dhikr ->
                val n = counts[dhikr.id] ?: 0
                val done = n >= dhikr.target

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !done) {
                            val value = DhikrProgress.increment(context, dhikr.id, dhikr.target)
                            counts[dhikr.id] = value
                            haptic.performHapticFeedback(
                                if (value >= dhikr.target) HapticFeedbackType.LongPress
                                else HapticFeedbackType.TextHandleMove
                            )
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = if (done) Color(0xFFDCEFE5)
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(dhikr.text, fontSize = 20.sp, lineHeight = 34.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = if (done) "✓ تم  ($n/${dhikr.target})" else "$n / ${dhikr.target}",
                            color = Color(0xFF1B6B4F),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
